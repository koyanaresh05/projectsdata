//WIFI NAME
const char* ssid = "Shubham";

//WIFI PASSWORD
const char* password = "1.2.3.4.";



//MongoDB ENDPOINT URL
/****************************************************************************************************************
Each https endpoint in a Realm(APP SERVICES) app has a common string concatinated with specific endpoint extension
Foreg: for endpoint named "post" ==>>  URL = endpoint_url + "post"
***************************************************************************************************************/

String endpoint_url = "https://us-east-1.aws.data.mongodb-api.com/app/10minexample-fzdpe/endpoint/";
String endpoint_url_post = "https://us-east-1.aws.data.mongodb-api.com/app/10minexample-fzdpe/endpoint/new_post_bus";
